const jwt = require('jsonwebtoken');
const {
  DynamoDBClient,
  ScanCommand,
} = require('@aws-sdk/client-dynamodb');

const JWT_SECRET = process.env.JWT_SECRET;
const TABLE_NAME = process.env.MESSAGES_TABLE;

const db = new DynamoDBClient({});

exports.handler = async (event) => {
  try {
    const authHeader =
      event.headers?.Authorization || event.headers?.authorization || '';
    const token = authHeader.startsWith('Bearer ')
      ? authHeader.slice(7)
      : null;

    if (!token) {
      return unauthorized();
    }

    try {
      const payload = jwt.verify(token, JWT_SECRET);
      if (payload.role !== 'admin') {
        return unauthorized();
      }
    } catch (err) {
      console.error('JWT verify error', err);
      return unauthorized();
    }

    const result = await db.send(
      new ScanCommand({
        TableName: TABLE_NAME,
        Limit: 100,
      })
    );

    const items = (result.Items || []).map((item) => ({
      id: item.id?.S,
      name: item.name?.S,
      email: item.email?.S,
      message: item.message?.S,
      createdAt: item.createdAt?.S,
    }));

    return {
      statusCode: 200,
      headers: corsHeaders(),
      body: JSON.stringify({ items }),
    };
  } catch (err) {
    console.error(err);
    return {
      statusCode: 500,
      headers: corsHeaders(),
      body: JSON.stringify({ message: 'Server error' }),
    };
  }
};

function unauthorized() {
  return {
    statusCode: 401,
    headers: corsHeaders(),
    body: JSON.stringify({ message: 'Unauthorized' }),
  };
}

function corsHeaders() {
  return {
    'Access-Control-Allow-Origin': 'https://joshuasuzuki.com',
    'Access-Control-Allow-Headers': 'Content-Type,Authorization',
    'Access-Control-Allow-Methods': 'OPTIONS,GET',
  };
}
